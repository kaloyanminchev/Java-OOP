import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

       try {
           List<Team> teams = new ArrayList<>();

           String input = scanner.nextLine();
           while (!input.equals("END")) {
               String[] tokens = input.split(";");

               switch (tokens[0]) {
                   case "Team":
                       Team team = new Team(tokens[1]);
                       teams.add(team);
                       break;
                   case "Add":
                       for (Team t : teams) {
                           if (tokens[1].equals(t.getName())) {
                               t.addPlayer(new Player(tokens[2],
                                       Integer.parseInt(tokens[3]),
                                       Integer.parseInt(tokens[4]),
                                       Integer.parseInt(tokens[5]),
                                       Integer.parseInt(tokens[6]),
                                       Integer.parseInt(tokens[7]))
                               );
                               break;
                           } else {
                               System.out.println(String.format("Team %s does not exist.", tokens[1]));
                           }
                       }
                       break;
                   case "Remove":
                       for (Team t : teams) {
                           if (tokens[1].equals(t.getName())) {
                               t.removePlayer(tokens[2]);
                           }
                       }
                       break;
                   case "Rating":
                       for (Team t : teams) {
                           if (t.getName().equals(tokens[1])) {
                               System.out.println(t.toString());
                           } else {
                               System.out.println(String.format("Team %s does not exist.", tokens[1]));
                           }
                       }
                       break;
               }

               input = scanner.nextLine();
           }

       } catch (IllegalArgumentException ex) {
           System.out.println(ex.getMessage());
       }
    }
}
